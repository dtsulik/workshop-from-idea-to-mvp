const AWS = require("aws-sdk");
var s3 = new AWS.S3();

module.exports.handler = (event, context, callback) => {
  var buf = Buffer.from(event.body.replace(/^data:image\/\w+;base64,/, ""),"base64");
  var response = "none";
  var data = {
    Bucket: process.env.BUCKET_NAME, 
    Key: "images/" + Date.now()+".png", 
    Body: buf,
    ContentType: 'image/png',
    ACL: 'public-read'
  };
  s3.putObject(data, function(err, data){
      var res ={
          "statusCode": 200,
          "headers": {
              "Content-Type": "*/*"
          }
      };
      
      if (err) {
        console.log(err);
        res.body = JSON.stringify('Error uploading data: ', data); 
        res.statusCode = 401;
        
        console.log('Error uploading data: ', data); 
        
      } else {
        res.body = JSON.stringify("succesfully uploaded the image!"); 
        console.log('succesfully uploaded the image!');
      }
      callback(null, res);
  });
};