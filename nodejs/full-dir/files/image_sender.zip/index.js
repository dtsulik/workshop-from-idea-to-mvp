const aws = require('aws-sdk');

const s3 = new aws.S3({ apiVersion: '2006-03-01' });


exports.handler =  (event, context, callback) => {
      var res ={
          "statusCode": 200,
          "headers": {
              "Content-Type": "*/*"
          }
      };
     var params = {
      Bucket: process.env.BUCKET_NAME,
      Prefix: "images/"
     };
     s3.listObjects(params, function(err, data) {
       if (err) console.log(err, err.stack); // an error occurred
       else     console.log(data);           // successful response
       res.body = JSON.stringify(data.Contents); 
       callback(null, res);
     });
};
